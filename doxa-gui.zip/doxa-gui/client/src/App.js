import React, { Component } from "react";
import "./App.css";
import styled from 'styled-components';
import { Card, Heading, Pill } from 'rimble-ui';

import PrizedLinkedContract from "./contracts/PrizedLinkedContract.json";
import getWeb3 from "./utils/getWeb3";

const Button = styled.button`
  background: red;
  border-radius: 3px;
  border: 2px solid red;
  color: white;
  margin: 1em 1em;
  padding: 0.25em 1em;
`

class App extends Component {
  state = { 
    web3: null, 
    accounts: null, 
    contract: null,
    manager: "",
    entrants:[],
    // pool: "",
    // amount:" ",
    message: ""
  };

  componentDidMount = async () => {
    try {
      const web3 = await getWeb3(); // Get network provider and web3 instance.
      const accounts = await web3.eth.getAccounts(); // Use web3 to get the user's accounts.
      const networkId = await web3.eth.net.getId(); // Get the contract instance.
      const deployedNetwork = PrizedLinkedContract.networks[networkId];
      const instance = new web3.eth.Contract(
        PrizedLinkedContract.abi,
        deployedNetwork && deployedNetwork.address,
      );
      const manager = await instance.methods.owner().call();
      const entrants = await instance.methods.entrants(0).call(); //!ADDED
      // const pool = await web3.eth.getBalance(instance.options.address);

      // Set web3, accounts, and contract to the state, and then proceed with an
      // example of interacting with the contract's methods.

      this.setState({ web3, accounts, contract: instance, manager, entrants }); //!ADDED entrants
    } catch (error) {
      // Catch any errors for any of the above operations.
      alert(
        `Failed to load web3, accounts, or contract. Check console for details.`,
      );
      console.error(error);
    }
  };

  //TODO: COMES FROM ETHLottery-GUI
  // onSubmit = async event => {
  //   event.preventDefault();
  //   const accounts = await web3.eth.getAccounts();
  //   this.setState({message: "Waiting for transaction to be confirmed..."});
  //   // TODO: lottery...
  //   await lottery.methods.enter().send({
  //     from:accounts[0],
  //     value:web3.utils.toWei(this.state.amount,'ether')
  //   });
  //   this.setState({message: "You have been entered successfully"});
  // }

  onClick = async () => {
      const accounts = await this.state.web3.eth.getAccounts();
      const entryAmount = this.state.web3.utils.toWei("10", "finney");
      // console.log(this.state.contract);
      this.state.contract.methods.addToPool().send({
        from: accounts[0],
        value: entryAmount
      });
      this.setState({ message: "10 Finney Saved!" }); // this.setState({ message: "Waiting for the transaction to be confirmed..." });
      // await lottery.methods.pickWinner().send({from: accounts[0]});
      // this.setState({message: `Winner is ${await lottery.methods.lastWinner().call()} picked`});
  }
  //TODO: COMES FROM ETHLottery-GUI

  render() {
    if (!this.state.web3) {
      return <div>Loading Web3, accounts, and contract...</div>;
    }
    return (
      <div className="App">
        <Card width={"500px"} mx={"auto"} px={4}>

          <Heading.h1>DOXA Pool Contract</Heading.h1>

          <p>You've installed DOXA and are ready to give it a spin!</p>
          <br />
          <Pill><h4><u>Current Injected Web3 Account </u>{this.state.accounts[0]}</h4></Pill>
          <br />
          <hr width="50%" />
          <Pill><h4><u>Smart Contract Manager (Owner) </u>{this.state.manager}</h4></Pill>

        </Card>

        <Card width={"500px"} mx={"auto"} px={4}>

          <h2><u>Simulate</u></h2>

          <Button onClick = { this.onClick }>Add 10 Finney to pool</Button>

          <h1>{ this.state.message }</h1>

        </Card>

        <Card width={"500px"} mx={"auto"} px={4}>

          <h4>The Winner can only be picked by the Smart Contract Manager</h4>

          <Button disabled>Draw Winner</Button>

        </Card>

      </div>
    );
  }
}

export default App;
