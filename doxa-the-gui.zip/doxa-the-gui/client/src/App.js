import React, { Component } from "react";
import "./App.css";
import styled from 'styled-components';
import { Card, Heading, Pill } from 'rimble-ui';

import PrizedLinkedContract from "./contracts/PrizedLinkedContract.json";
import getWeb3 from "./utils/getWeb3";

const Button = styled.button`
  background: red;
  border-radius: 3px;
  border: 2px solid red;
  color: white;
  margin: 1em 1em;
  padding: 0.25em 1em;
`

class App extends Component {
  state = { 
    web3: null, 
    accounts: null, 
    contract: null,
    manager:" ",
    message:" "
  };

  componentDidMount = async () => {
try {
      const web3 = await getWeb3(); // Get network provider and web3 instance.
      const accounts = await web3.eth.getAccounts(); // Use web3 to get the user's accounts.
      const networkId = await web3.eth.net.getId(); // Get the contract instance.
      const deployedNetwork = PrizedLinkedContract.networks[networkId];
      const instance = new web3.eth.Contract(
        PrizedLinkedContract.abi,
        deployedNetwork && deployedNetwork.address,
      );
      const manager = await instance.methods.owner().call();

      // Set web3, accounts, and contract to the state, and then proceed with an
      // example of interacting with the contract's methods.

      this.setState({ web3, accounts, contract: instance, manager }); 
    } catch (error) {
      // Catch any errors for any of the above operations.
      alert(
        `Failed to load web3, accounts, or contract. Check console for details.`,
      );
      console.error(error);
    }
  };

  onClick = async () => {
      const accounts = await this.state.web3.eth.getAccounts();
      const entryAmount = this.state.web3.utils.toWei("10", "finney");
      this.state.contract.methods.addToPool().send({
        from: accounts[0],
        value: entryAmount
      });
      this.setState({ message: "10 Finney Saved!" });
  }

  render() {
    if (!this.state.web3) {
      return <div>Loading Web3, accounts, and contract...</div>;
    }
    return (
      <div className="App">
        <Card width={"500px"} mx={"auto"} px={4}>

          <Heading.h1>DOXA Pool Contract</Heading.h1>

          <p>You've installed DOXA and are ready to give it a spin!</p>
          <br />
          <Pill><h4><u>Current Injected Web3 Account </u>{this.state.accounts[0]}</h4></Pill>
          <br />
          <hr width="50%" />
          <Pill><h4><u>Smart Contract Manager (Owner) </u>{this.state.manager}</h4></Pill>

        </Card>

        <Card width={"500px"} mx={"auto"} px={4}>

          <h2><u>Simulate</u></h2>

          <Button onClick = { this.onClick }>Add 10 Finney to Pool</Button>

          <h1>{ this.state.message }</h1>

        </Card>

        <Card width={"500px"} mx={"auto"} px={4}>

          <h4>The Winner can only be picked by the Smart Contract Manager</h4>

          <Button disabled>Draw Winner</Button>

        </Card>

      </div>
    );
  }
}

export default App;
